# TinyML_Workshop_ICAC_2024


Welcome to the TinyML Workshop at ICAC 2024! This workshop will cover the fundamentals and advancements in Tiny Machine Learning (TinyML). We also have a mobile app and a Colab notebook to enhance your learning experience. You can find the TFLite file in the following link: 
[TFLite File](https://drive.google.com/drive/folders/1Ims1QtMa_EgzQv5ijsN8zqEqQzZ4dJTx?usp=share_link).


You can access the Colab notebook here: [Colab Notebook](https://colab.research.google.com/drive/1bR1FMca4nlLMLtoiTPf4nf1Ht43ETUiX?usp=sharing).